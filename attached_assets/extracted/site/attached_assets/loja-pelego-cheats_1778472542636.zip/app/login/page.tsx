"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [isLogin, setIsLogin] = useState(true);

  const [registerData, setRegisterData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  // Verificar se já está logado
  useEffect(() => {
    const loggedUser = localStorage.getItem("nexox_logged_user");
    if (loggedUser) {
      router.push("/");
    }
  }, [router]);

  // CADASTRO
  const handleRegister = () => {
    if (
      !registerData.username ||
      !registerData.email ||
      !registerData.password
    ) {
      alert("Preencha todos os campos!");
      return;
    }

    localStorage.setItem("nexox_user", JSON.stringify(registerData));
    alert("Conta criada com sucesso!");
    setIsLogin(true);
  };

  // LOGIN
  const handleLogin = () => {
    const savedUser = JSON.parse(localStorage.getItem("nexox_user") || "null");

    if (!savedUser) {
      alert("Nenhuma conta encontrada!");
      return;
    }

    if (
      loginData.email === savedUser.email &&
      loginData.password === savedUser.password
    ) {
      localStorage.setItem("nexox_logged_user", JSON.stringify(savedUser));
      router.push("/");
    } else {
      alert("Email ou senha incorretos!");
    }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden font-sans relative flex items-center justify-center">
      {/* BACKGROUND */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-zinc-900 to-zinc-700 opacity-90" />

      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full bg-[linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      {/* Glow decorativo */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/10 blur-[150px] rounded-full" />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-white/5 blur-[120px] rounded-full" />

      {/* CARD DE LOGIN/CADASTRO */}
      <div className="relative z-10 w-full max-w-md mx-4">
        {/* Logo e título */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex flex-col items-center gap-4 group">
            <div className="w-20 h-20 rounded-3xl bg-white flex items-center justify-center shadow-2xl group-hover:scale-105 transition-transform">
              <img
                src="/logo.png"
                alt="NEXOX GROUP"
                className="w-14 h-14 object-contain"
              />
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-wide">NEXOX GROUP</h1>
              <p className="text-zinc-400 text-sm">Premium PC Store</p>
            </div>
          </Link>
        </div>

        {/* Card principal */}
        <div className="rounded-[40px] border border-white/10 bg-white/5 backdrop-blur-2xl p-8 shadow-[0_0_80px_rgba(255,255,255,0.08)]">
          {/* Tabs */}
          <div className="flex mb-8 bg-black/40 rounded-2xl p-1">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 rounded-2xl font-bold transition-all ${
                isLogin ? "bg-white text-black" : "text-zinc-400 hover:text-white"
              }`}
            >
              Login
            </button>

            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 rounded-2xl font-bold transition-all ${
                !isLogin ? "bg-white text-black" : "text-zinc-400 hover:text-white"
              }`}
            >
              Cadastro
            </button>
          </div>

          {isLogin ? (
            <div className="space-y-5">
              <div>
                <h3 className="font-black text-3xl mb-2">Bem-vindo de volta</h3>
                <p className="text-zinc-400 text-sm">Entre na sua conta para continuar</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Email</label>
                  <input
                    type="email"
                    placeholder="seu@email.com"
                    value={loginData.email}
                    onChange={(e) =>
                      setLoginData({
                        ...loginData,
                        email: e.target.value,
                      })
                    }
                    className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors placeholder:text-zinc-600"
                  />
                </div>

                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Senha</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={loginData.password}
                    onChange={(e) =>
                      setLoginData({
                        ...loginData,
                        password: e.target.value,
                      })
                    }
                    className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors placeholder:text-zinc-600"
                  />
                </div>
              </div>

              <button
                onClick={handleLogin}
                className="w-full py-4 rounded-2xl bg-white text-black font-black hover:scale-[1.02] transition-all shadow-lg"
              >
                Fazer Login
              </button>

              <p className="text-center text-zinc-500 text-sm">
                Não tem uma conta?{" "}
                <button
                  onClick={() => setIsLogin(false)}
                  className="text-white hover:underline"
                >
                  Criar conta
                </button>
              </p>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <h3 className="font-black text-3xl mb-2">Criar Conta</h3>
                <p className="text-zinc-400 text-sm">Cadastre-se para começar a comprar</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Nome de usuário</label>
                  <input
                    type="text"
                    placeholder="Seu nome"
                    value={registerData.username}
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        username: e.target.value,
                      })
                    }
                    className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors placeholder:text-zinc-600"
                  />
                </div>

                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Email</label>
                  <input
                    type="email"
                    placeholder="seu@email.com"
                    value={registerData.email}
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        email: e.target.value,
                      })
                    }
                    className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors placeholder:text-zinc-600"
                  />
                </div>

                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Senha</label>
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={registerData.password}
                    onChange={(e) =>
                      setRegisterData({
                        ...registerData,
                        password: e.target.value,
                      })
                    }
                    className="w-full p-4 rounded-2xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors placeholder:text-zinc-600"
                  />
                </div>
              </div>

              <button
                onClick={handleRegister}
                className="w-full py-4 rounded-2xl bg-white text-black font-black hover:scale-[1.02] transition-all shadow-lg"
              >
                Criar Conta
              </button>

              <p className="text-center text-zinc-500 text-sm">
                Já tem uma conta?{" "}
                <button
                  onClick={() => setIsLogin(true)}
                  className="text-white hover:underline"
                >
                  Fazer login
                </button>
              </p>
            </div>
          )}
        </div>

        {/* Link para voltar */}
        <div className="text-center mt-6">
          <Link
            href="/"
            className="text-zinc-500 hover:text-white transition-colors text-sm inline-flex items-center gap-2"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Voltar para a loja
          </Link>
        </div>
      </div>
    </div>
  );
}
