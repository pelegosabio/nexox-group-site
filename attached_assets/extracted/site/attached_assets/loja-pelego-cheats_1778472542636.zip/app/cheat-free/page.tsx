"use client";

import { useState } from "react";
import Link from "next/link";

export default function CheatFreePage() {
  const [step, setStep] = useState<"instructions" | "chat" | "download">("instructions");
  const [messages, setMessages] = useState<{ sender: "user" | "admin"; text: string; image?: string }[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleSendMessage = () => {
    if (!inputMessage.trim() && !selectedImage) return;

    const newMessage: { sender: "user" | "admin"; text: string; image?: string } = {
      sender: "user",
      text: inputMessage,
    };

    if (selectedImage) {
      newMessage.image = selectedImage;
    }

    setMessages([...messages, newMessage]);
    setInputMessage("");
    setSelectedImage(null);

    // Simular resposta do admin após 2 segundos
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          sender: "admin",
          text: "Obrigado por enviar o print! Estamos verificando sua inscrição no canal. Aguarde um momento...",
        },
      ]);

      // Simular verificação e liberação após 3 segundos
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            sender: "admin",
            text: "Inscrição verificada com sucesso! Seu download foi liberado.",
          },
        ]);
        setStep("download");
      }, 3000);
    }, 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden font-sans relative flex flex-col">
      {/* BACKGROUND */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-zinc-900 to-zinc-700 opacity-90" />
      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full bg-[linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/10 blur-[150px] rounded-full" />

      {/* HEADER */}
      <header className="relative z-10 border-b border-white/10 backdrop-blur-xl bg-white/5">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-8 py-5">
          <Link href="/" className="flex items-center gap-4 group">
            <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-2xl group-hover:scale-105 transition-transform">
              <img src="/logo.png" alt="logo" className="w-10 h-10 object-contain" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-wide">NEXOX GROUP</h1>
              <p className="text-zinc-400 text-sm">Premium PC Store</p>
            </div>
          </Link>

          <Link
            href="/"
            className="px-5 py-2 rounded-xl border border-white/20 hover:bg-white hover:text-black transition-all flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Voltar
          </Link>
        </div>
      </header>

      {/* CONTENT */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-12">
        {step === "instructions" && (
          <div className="w-full max-w-2xl">
            <div className="rounded-[40px] border border-white/10 bg-white/5 backdrop-blur-2xl p-8 md:p-12 shadow-[0_0_80px_rgba(255,255,255,0.08)]">
              <div className="text-center mb-8">
                <div className="w-20 h-20 rounded-3xl bg-white flex items-center justify-center mx-auto mb-6 shadow-2xl">
                  <img src="/logo.png" alt="NEXOX GROUP" className="w-14 h-14 object-contain" />
                </div>
                <h2 className="text-3xl md:text-4xl font-black mb-4">CHEAT FREE</h2>
                <p className="text-zinc-400 text-lg">Siga os passos abaixo para liberar seu download</p>
              </div>

              <div className="space-y-6 mb-10">
                <div className="flex items-start gap-4 p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-white text-black font-black flex items-center justify-center shrink-0">
                    1
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Inscreva-se no Canal</h3>
                    <p className="text-zinc-400 mb-4">
                      Primeiro, inscreva-se no canal NEXOX GROUP no YouTube clicando no botão abaixo.
                    </p>
                    <a
                      href="https://www.youtube.com/@NEXOXGROUP"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700 hover:scale-105 transition-all"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                      </svg>
                      Inscrever no YouTube
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-white text-black font-black flex items-center justify-center shrink-0">
                    2
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Envie o Print da Inscrição</h3>
                    <p className="text-zinc-400">
                      Após se inscrever, tire um print mostrando que você está inscrito no canal e envie no chat de verificação.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-white text-black font-black flex items-center justify-center shrink-0">
                    3
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Aguarde a Verificação</h3>
                    <p className="text-zinc-400">
                      Nossa equipe verificará sua inscrição e liberará o download do Cheat Free automaticamente.
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setStep("chat")}
                className="w-full py-4 rounded-2xl bg-white text-black font-black text-lg hover:scale-[1.02] transition-all shadow-lg"
              >
                Já me inscrevi - Enviar Print
              </button>
            </div>
          </div>
        )}

        {step === "chat" && (
          <div className="w-full max-w-2xl h-[600px] flex flex-col">
            <div className="rounded-t-[32px] border border-white/10 border-b-0 bg-white/5 backdrop-blur-2xl p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center">
                  <img src="/logo.png" alt="NEXOX" className="w-8 h-8 object-contain" />
                </div>
                <div>
                  <h3 className="font-black text-xl">Chat de Verificação</h3>
                  <p className="text-zinc-400 text-sm">Envie o print da sua inscrição</p>
                </div>
              </div>
            </div>

            <div className="flex-1 border-x border-white/10 bg-black/40 p-6 overflow-y-auto space-y-4">
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-2xl rounded-tl-sm bg-zinc-800 p-4">
                  <p className="text-sm text-zinc-300">
                    Olá! Envie aqui o print mostrando que você está inscrito no canal NEXOX GROUP no YouTube.
                  </p>
                </div>
              </div>

              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-2xl p-4 ${
                      msg.sender === "user"
                        ? "rounded-tr-sm bg-white text-black"
                        : "rounded-tl-sm bg-zinc-800 text-zinc-300"
                    }`}
                  >
                    {msg.image && (
                      <img src={msg.image} alt="Print" className="rounded-xl mb-2 max-w-full" />
                    )}
                    {msg.text && <p className="text-sm">{msg.text}</p>}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-b-[32px] border border-white/10 border-t-0 bg-white/5 backdrop-blur-2xl p-4">
              {selectedImage && (
                <div className="mb-3 relative inline-block">
                  <img src={selectedImage} alt="Preview" className="h-20 rounded-xl" />
                  <button
                    onClick={() => setSelectedImage(null)}
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center"
                  >
                    X
                  </button>
                </div>
              )}
              <div className="flex gap-3">
                <label className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center cursor-pointer hover:bg-zinc-700 transition-colors">
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  <svg className="w-5 h-5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                    />
                  </svg>
                </label>
                <input
                  type="text"
                  placeholder="Digite uma mensagem..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  className="flex-1 px-5 py-3 rounded-xl bg-black/40 border border-white/10 outline-none focus:border-white/30 transition-colors"
                />
                <button
                  onClick={handleSendMessage}
                  className="px-6 py-3 rounded-xl bg-white text-black font-bold hover:scale-105 transition-all"
                >
                  Enviar
                </button>
              </div>
            </div>
          </div>
        )}

        {step === "download" && (
          <div className="w-full max-w-2xl">
            <div className="rounded-[40px] border border-white/10 bg-white/5 backdrop-blur-2xl overflow-hidden shadow-[0_0_80px_rgba(255,255,255,0.08)]">
              <div className="p-8 md:p-10 text-center border-b border-white/10">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 border border-green-500/30 mb-6">
                  <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-green-400 font-bold text-sm">Verificação Aprovada</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-black mb-2">Download do Cheat Free</h2>
                <p className="text-zinc-400 text-lg">NEXOX GROUP</p>
              </div>

              <div className="p-4">
                <img
                  src="/cheat-preview.png"
                  alt="Cheat Free Preview"
                  className="w-full rounded-2xl border border-white/10"
                />
              </div>

              <div className="p-8 md:p-10">
                <a
                  href="https://cdn.discordapp.com/attachments/1498532721151049829/1503205337010798702/LOADER_FREE_NEXOX_GROUP.exe?ex=6a028090&is=6a012f10&hm=58d2e5e5f77452a088c98b70f9eb086a0b284fe6962e21c7ca4d9208d1e51bcc&"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-5 rounded-2xl bg-white text-black font-black text-lg hover:scale-[1.02] transition-all shadow-lg flex items-center justify-center gap-3"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                    />
                  </svg>
                  Download
                </a>

                <p className="text-center text-zinc-500 text-sm mt-6">
                  Obrigado por se inscrever no canal NEXOX GROUP!
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/10 py-6 px-8 text-center text-zinc-500 text-sm">
        © 2026 NEXOX GROUP — Todos os direitos reservados.
      </footer>
    </div>
  );
}
