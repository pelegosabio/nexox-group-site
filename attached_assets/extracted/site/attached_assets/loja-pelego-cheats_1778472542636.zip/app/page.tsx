"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function NexoxGroupStore() {
  const [loggedUser, setLoggedUser] = useState<{
    username: string;
    email: string;
    password: string;
  } | null>(null);

  // Verificar se está logado ao carregar a página
  useEffect(() => {
    const user = localStorage.getItem("nexox_logged_user");
    if (user) {
      setLoggedUser(JSON.parse(user));
    }
  }, []);

  // LOGOUT
  const handleLogout = () => {
    localStorage.removeItem("nexox_logged_user");
    setLoggedUser(null);
  };

  const [openModal, setOpenModal] = useState<"rage" | "lite" | null>(null);

  const ragePlans = [
    { name: "Diário", price: "R$ 5,00" },
    { name: "Semanal", price: "R$ 15,00" },
    { name: "15 Dias", price: "R$ 20,00" },
    { name: "Mensal", price: "R$ 30,00" },
    { name: "Trimensal", price: "R$ 43,99" },
    { name: "Permanente", price: "R$ 50,00" },
  ];

  const litePlans = [
    { name: "Diário", price: "R$ 4,00" },
    { name: "Semanal", price: "R$ 13,00" },
    { name: "Mensal", price: "R$ 27,00" },
    { name: "Permanente", price: "R$ 45,90" },
  ];

  const products = [
    {
      id: "rage",
      title: "RAGE PANEL",
      desc: "Melhor performance e funções premium.",
    },
    {
      id: "lite",
      title: "LITE PANEL",
      desc: "Mais leve e otimizado para qualquer PC.",
    },
    {
      id: "free",
      title: "CHEAT FREE",
      desc: "Versão gratuita para testar o sistema.",
    },
  ];



  return (
    <div className="min-h-screen bg-black text-white overflow-hidden font-sans relative">
      {/* BACKGROUND */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-zinc-900 to-zinc-700 opacity-90" />

      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full bg-[linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      {/* HEADER */}
      <header className="relative z-10 border-b border-white/10 backdrop-blur-xl bg-white/5">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-8 py-5">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-2xl">
              <img
                src="/logo.png"
                alt="logo"
                className="w-10 h-10 object-contain"
              />
            </div>

            <div>
              <h1 className="text-2xl font-black tracking-wide">NEXOX GROUP</h1>

              <p className="text-zinc-400 text-sm">Premium PC Store</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {loggedUser ? (
              <>
                <div className="px-5 py-2 rounded-xl border border-white/10 bg-white/5">
                  {loggedUser.username}
                </div>

                <button
                  onClick={handleLogout}
                  className="px-5 py-2 rounded-xl bg-white text-black font-bold hover:scale-105 transition-all"
                >
                  Sair
                </button>
              </>
            ) : (
              <>
                <Link
                  href="/login"
                  className="px-5 py-2 rounded-xl border border-white/20 hover:bg-white hover:text-black transition-all"
                >
                  Entrar
                </Link>

                <Link
                  href="/login"
                  className="px-5 py-2 rounded-xl bg-white text-black font-bold hover:scale-105 transition-all"
                >
                  Cadastro
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* HERO */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pt-24 pb-20 grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 mb-6 backdrop-blur-xl">
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
            <span className="text-sm text-zinc-300">
              Entrega automática via PIX
            </span>
          </div>

          <h2 className="text-6xl leading-tight font-black mb-6">
            NEXOX
            <br />
            <span className="text-zinc-400">GROUP STORE</span>
          </h2>

          <p className="text-zinc-400 text-lg leading-relaxed max-w-xl mb-10">
            Loja premium focada em performance, visual moderno e sistema
            automatizado. Compre, pague no PIX e receba instantaneamente.
          </p>

          <div className="flex flex-wrap gap-4">
            <button className="px-8 py-4 rounded-2xl bg-white text-black font-black hover:scale-105 transition-all duration-300 shadow-2xl">
              Comprar Agora
            </button>

            <button className="px-8 py-4 rounded-2xl border border-white/20 backdrop-blur-xl hover:bg-white/10 transition-all duration-300">
              Ver Catálogo
            </button>
          </div>
        </div>

        {/* Card de Status do Painel */}
        <div className="relative flex justify-center">
          <div className="absolute w-96 h-96 bg-white/20 blur-[120px] rounded-full" />

          <div className="relative w-full max-w-md rounded-[40px] border border-white/10 bg-white/5 backdrop-blur-2xl p-8 shadow-[0_0_80px_rgba(255,255,255,0.08)]">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="font-black text-2xl">PAINEL PREMIUM</h3>
                <p className="text-zinc-400 text-sm">Atualização diária</p>
              </div>
              <div className="px-4 py-2 rounded-xl bg-white text-black font-black text-sm">
                ONLINE
              </div>
            </div>

            <div className="space-y-4">
              {[
                "Aim Assist",
                "Visual Premium",
                "Performance Mode",
                "Menu Clean",
                "Suporte 24h",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between p-4 rounded-2xl bg-black/40 border border-white/10"
                >
                  <span>{item}</span>
                  <div className="w-3 h-3 rounded-full bg-white" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PRODUTOS */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pb-24">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h3 className="text-4xl font-black mb-2">Produtos</h3>

            <p className="text-zinc-400">Escolha seu plano ideal</p>
          </div>

          <div className="px-5 py-3 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl">
            PIX AUTOMÁTICO
          </div>
        </div>

        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-8">
          {products.map((product) => (
            <div
              key={product.title}
              className="group relative rounded-[32px] border border-white/10 bg-white/5 p-8 backdrop-blur-2xl hover:scale-[1.02] transition-all duration-300 overflow-hidden"
            >
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-500 bg-gradient-to-br from-white/10 to-transparent" />

              <div className="relative z-10">
                <div className="w-20 h-20 rounded-3xl bg-white flex items-center justify-center mb-8 shadow-2xl">
                  <img
                    src="/logo.png"
                    alt="logo"
                    className="w-12 h-12 object-contain"
                  />
                </div>

                <h4 className="text-3xl font-black mb-3">{product.title}</h4>

                <p className="text-zinc-400 mb-8 leading-relaxed">
                  {product.desc}
                </p>

                {product.id === "free" ? (
                  <Link
                    href="/cheat-free"
                    className="w-full px-6 py-3 rounded-2xl bg-zinc-800 text-white font-bold hover:bg-zinc-700 hover:scale-105 transition-all duration-300 block text-center"
                  >
                    Baixar Grátis
                  </Link>
                ) : (
                  <button
                    onClick={() => setOpenModal(product.id as "rage" | "lite")}
                    className="w-full px-6 py-3 rounded-2xl bg-white text-black font-bold hover:scale-105 transition-all duration-300"
                  >
                    Comprar
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SUPORTE */}
      <section className="relative z-10 max-w-7xl mx-auto px-8 pb-24">
        <div className="rounded-[40px] border border-white/10 bg-white/5 backdrop-blur-2xl p-10 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div>
            <h3 className="text-4xl font-black mb-4">Sistema de Tickets</h3>

            <p className="text-zinc-400 max-w-2xl text-lg leading-relaxed">
              Suporte integrado com tickets, Discord webhook, notificações e
              atendimento rápido.
            </p>
          </div>

          <button className="px-8 py-4 rounded-2xl bg-white text-black font-black hover:scale-105 transition-all duration-300 whitespace-nowrap">
            Abrir Ticket
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative z-10 border-t border-white/10 py-8 px-8 text-center text-zinc-500">
        © 2026 NEXOX GROUP — Todos os direitos reservados.
      </footer>

      {/* MODAIS DE COMPRA */}
      {openModal === "rage" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="w-[95%] max-w-md rounded-[32px] border border-white/10 bg-zinc-950 p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-black text-white">Comprar RAGE</h2>
              <button
                onClick={() => setOpenModal(null)}
                className="rounded-xl bg-red-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-red-600"
              >
                X
              </button>
            </div>
            <div className="space-y-3">
              {ragePlans.map((plan) => (
                <button
                  key={plan.name}
                  className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-left transition hover:bg-white/10"
                  onClick={() => alert(`Você selecionou:\n\nRAGE - ${plan.name}\n${plan.price}`)}
                >
                  <div>
                    <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                    <p className="text-sm text-zinc-400">Key de acesso premium</p>
                  </div>
                  <span className="text-lg font-black text-white">{plan.price}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {openModal === "lite" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="w-[95%] max-w-md rounded-[32px] border border-white/10 bg-zinc-950 p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-black text-white">Comprar LITE</h2>
              <button
                onClick={() => setOpenModal(null)}
                className="rounded-xl bg-red-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-red-600"
              >
                X
              </button>
            </div>
            <div className="space-y-3">
              {litePlans.map((plan) => (
                <button
                  key={plan.name}
                  className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-left transition hover:bg-white/10"
                  onClick={() => alert(`Você selecionou:\n\nLITE - ${plan.name}\n${plan.price}`)}
                >
                  <div>
                    <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                    <p className="text-sm text-zinc-400">Key de acesso premium</p>
                  </div>
                  <span className="text-lg font-black text-white">{plan.price}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
